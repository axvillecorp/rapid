System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var CompanyData;
    return {
        setters:[],
        execute: function() {
            CompanyData = (function () {
                function CompanyData() {
                }
                return CompanyData;
            }());
            exports_1("CompanyData", CompanyData);
        }
    }
});
//# sourceMappingURL=companyData.js.map