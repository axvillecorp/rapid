System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ContactData;
    return {
        setters:[],
        execute: function() {
            ContactData = (function () {
                function ContactData() {
                }
                return ContactData;
            }());
            exports_1("ContactData", ContactData);
        }
    }
});
//# sourceMappingURL=contactData.js.map