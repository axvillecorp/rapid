
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import {CompanyData} from './companyData';

/// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class CompanyService {

    /// Resolve HTTP using the constructor
    // constructor(private http: Http) { }

    /// private instance variable to hold base url
    private companiesUrl = 'app/appData.json'
    /// Get companoes from server...
    getCompanies(): any {

        /// return data
        return [
            {
                "Id": 1000,
                "Name": "Afton United",
                "Federal_id":"41592020",
                "Address_1": "1808 Aston Ave",
                "Address_2":"Suite 270",
                "City":"Carlsbad",
                "State":"CA",
                "Zip":"92008",
                "Phone": "415 699 3193",
                "Fax": "415 777 1111",
                "Type": [
                    {
                     "TypeId": 1,
                      "TypeValue": "Accountant"
                    },
                    {
                     "TypeId": 2,
                      "TypeValue": "Architect"
                    },
                    {
                     "TypeId": 3,
                      "TypeValue": "Attorney"
                    },
                    {
                     "TypeId": 4,
                      "TypeValue": "Developer"
                    },
                    {
                     "TypeId": 5,
                      "TypeValue": "Escrow Agent"
                    },
                    {
                     "TypeId": 6,
                      "TypeValue": "FM HA District"
                    },
                    {
                     "TypeId": 7,
                      "TypeValue": "FM HA State"
                    },
                    {
                     "TypeId": 8,
                      "TypeValue": "General Contractor"
                    },
                    {
                     "TypeId": 9,
                      "TypeValue": "General Partner"
                    },
                    {
                     "TypeId": 10,
                      "TypeValue": "Investor"
                    },
                    {
                     "TypeId": 11,
                      "TypeValue": "Guarantor"
                    },
                    {
                     "TypeId": 12,
                      "TypeValue": "Lender"
                    },
                    {
                     "TypeId": 13,
                      "TypeValue": "Management Company"
                    },
                    {
                     "TypeId": 14,
                      "TypeValue": "Special LP"
                    },
                    {
                     "TypeId": 15,
                      "TypeValue": "Tax Accountant"
                    },

                    {
                     "TypeId": 16,
                      "TypeValue": "3rd Party Inspector"
                    },
                    {
                     "TypeId": 17,
                      "TypeValue": "Other"
                    }
                ],
                "Contacts": [
                    {
                        "ContactId": 1,
                        "FirstName": "John",
                        "LastName": "Smith",
                        "Phone": "214 2323 3123",
                        "Position": "Analyst",
                        "Department": "Finance"
                    },
                    {
                        "ContactId": 2,
                        "FirstName": "Kathy",
                        "LastName": "Kyle",
                        "Phone": "214 2100 3123",
                        "Position": "Specialyst",
                        "Department": "Accounting"
                    },
                    {
                        "ContactId": 3,
                        "FirstName": "Paul",
                        "LastName": "Luis",
                        "Phone": "214 2323 5100",
                        "Position": "Manager",
                        "Department": "Marketing"
                    }
                ]
            },
            
            {
                "Id": 1001,
                "Name": "Bfton United",
                "Federal_id":"41592021",
                "Address_1": "4102 Aston Ave",
                "Address_2":"Suite 570",
                "City":"Oakland",
                "State":"MA",
                "Zip":"94122",
                "Phone": "415 600 3193",
                "Fax": "415 777 22222",
                "Type": [
                    {
                     "TypeId": 1,
                      "TypeValue": "Accountant"
                    },
                    {
                     "TypeId": 2,
                      "TypeValue": "Architect"
                    },
                    {
                     "TypeId": 3,
                      "TypeValue": "Attorney"
                    },
                    {
                     "TypeId": 4,
                      "TypeValue": "Developer"
                    },
                    {
                     "TypeId": 5,
                      "TypeValue": "Escrow Agent"
                    },
                    {
                     "TypeId": 6,
                      "TypeValue": "FM HA District"
                    },
                    {
                     "TypeId": 7,
                      "TypeValue": "FM HA State"
                    },
                    {
                     "TypeId": 8,
                      "TypeValue": "General Contractor"
                    },
                    {
                     "TypeId": 9,
                      "TypeValue": "General Partner"
                    },
                    {
                     "TypeId": 10,
                      "TypeValue": "Investor"
                    },
                    {
                     "TypeId": 11,
                      "TypeValue": "Guarantor"
                    },
                    {
                     "TypeId": 12,
                      "TypeValue": "Lender"
                    },
                    {
                     "TypeId": 13,
                      "TypeValue": "Management Company"
                    },
                    {
                     "TypeId": 14,
                      "TypeValue": "Special LP"
                    },
                    {
                     "TypeId": 15,
                      "TypeValue": "Tax Accountant"
                    },

                    {
                     "TypeId": 16,
                      "TypeValue": "3rd Party Inspector"
                    },
                    {
                     "TypeId": 17,
                      "TypeValue": "Other"
                    }
                ],
                "Contacts": [
                    {
                        "ContactId": 1,
                        "FirstName": "Dan",
                        "LastName": "Smith",
                        "Phone": "214 2323 3123",
                        "Position": "Analyst",
                        "Department": "Finance"
                    },
                    {
                        "ContactId": 2,
                        "FirstName": "Dan",
                        "LastName": "Kyle",
                        "Phone": "214 2100 3123",
                        "Position": "Specialyst",
                        "Department": "Accounting"
                    },
                    {
                        "ContactId": 3,
                        "FirstName": "Dan",
                        "LastName": "Luis",
                        "Phone": "214 2323 5100",
                        "Position": "Manager",
                        "Department": "Marketing"
                    }
                ]
            },

            {
                "Id": 1002,
                "Name": "Cfton United",
                "Federal_id":"41592022",
                "Address_1": "1000 Aston Ave",
                "Address_2":"Suite 100",
                "City":"Florida",
                "State":"FA",
                "Zip":"91500",
                "Phone": "415 699 6900",
                "Fax": "415 777 3333",
                "Type": [
                    {
                     "TypeId": 1,
                      "TypeValue": "Accountant"
                    },
                    {
                     "TypeId": 2,
                      "TypeValue": "Architect"
                    },
                    {
                     "TypeId": 3,
                      "TypeValue": "Attorney"
                    },
                    {
                     "TypeId": 4,
                      "TypeValue": "Developer"
                    },
                    {
                     "TypeId": 5,
                      "TypeValue": "Escrow Agent"
                    },
                    {
                     "TypeId": 6,
                      "TypeValue": "FM HA District"
                    },
                    {
                     "TypeId": 7,
                      "TypeValue": "FM HA State"
                    },
                    {
                     "TypeId": 8,
                      "TypeValue": "General Contractor"
                    },
                    {
                     "TypeId": 9,
                      "TypeValue": "General Partner"
                    },
                    {
                     "TypeId": 10,
                      "TypeValue": "Investor"
                    },
                    {
                     "TypeId": 11,
                      "TypeValue": "Guarantor"
                    },
                    {
                     "TypeId": 12,
                      "TypeValue": "Lender"
                    },
                    {
                     "TypeId": 13,
                      "TypeValue": "Management Company"
                    },
                    {
                     "TypeId": 14,
                      "TypeValue": "Special LP"
                    },
                    {
                     "TypeId": 15,
                      "TypeValue": "Tax Accountant"
                    },

                    {
                     "TypeId": 16,
                      "TypeValue": "3rd Party Inspector"
                    },
                    {
                     "TypeId": 17,
                      "TypeValue": "Other"
                    }
                ],
                "Contacts": [
                    {
                        "ContactId": 1,
                        "FirstName": "John",
                        "LastName": "Messi",
                        "Phone": "214 2323 3123",
                        "Position": "Analyst",
                        "Department": "Finance"
                    },
                    {
                        "ContactId": 2,
                        "FirstName": "Kathy",
                        "LastName": "Messi",
                        "Phone": "214 2100 3123",
                        "Position": "Specialyst",
                        "Department": "Accounting"
                    },
                    {
                        "ContactId": 3,
                        "FirstName": "Paul",
                        "LastName": "Messi",
                        "Phone": "214 2323 5100",
                        "Position": "Manager",
                        "Department": "Marketing"
                    }
                ]
            },

            {
                "Id": 1003,
                "Name": "Dfton United",
                "Federal_id":"41592023",
                "Address_1": "2000 Aston Ave",
                "Address_2":"Suite 200",
                "City":"San Francisco",
                "State":"CA",
                "Zip":"94500",
                "Phone": "415 699 7800",
                "Fax": "415 777 4444",
                "Type": [
                    {
                     "TypeId": 1,
                      "TypeValue": "Accountant"
                    },
                    {
                     "TypeId": 2,
                      "TypeValue": "Architect"
                    },
                    {
                     "TypeId": 3,
                      "TypeValue": "Attorney"
                    },
                    {
                     "TypeId": 4,
                      "TypeValue": "Developer"
                    },
                    {
                     "TypeId": 5,
                      "TypeValue": "Escrow Agent"
                    },
                    {
                     "TypeId": 6,
                      "TypeValue": "FM HA District"
                    },
                    {
                     "TypeId": 7,
                      "TypeValue": "FM HA State"
                    },
                    {
                     "TypeId": 8,
                      "TypeValue": "General Contractor"
                    },
                    {
                     "TypeId": 9,
                      "TypeValue": "General Partner"
                    },
                    {
                     "TypeId": 10,
                      "TypeValue": "Investor"
                    },
                    {
                     "TypeId": 11,
                      "TypeValue": "Guarantor"
                    },
                    {
                     "TypeId": 12,
                      "TypeValue": "Lender"
                    },
                    {
                     "TypeId": 13,
                      "TypeValue": "Management Company"
                    },
                    {
                     "TypeId": 14,
                      "TypeValue": "Special LP"
                    },
                    {
                     "TypeId": 15,
                      "TypeValue": "Tax Accountant"
                    },

                    {
                     "TypeId": 16,
                      "TypeValue": "3rd Party Inspector"
                    },
                    {
                     "TypeId": 17,
                      "TypeValue": "Other"
                    }
                ],
                "Contacts": [
                    {
                        "ContactId": 1,
                        "FirstName": "Kiju",
                        "LastName": "Smith",
                        "Phone": "214 2323 3123",
                        "Position": "Analyst",
                        "Department": "Finance"
                    },
                    {
                        "ContactId": 2,
                        "FirstName": "Kiju",
                        "LastName": "Kyle",
                        "Phone": "214 2100 3123",
                        "Position": "Specialyst",
                        "Department": "Accounting"
                    },
                    {
                        "ContactId": 3,
                        "FirstName": "Kiju",
                        "LastName": "Luis",
                        "Phone": "214 2323 5100",
                        "Position": "Manager",
                        "Department": "Marketing"
                    }
                ]
            },

            {
                "Id": 1004,
                "Name": "Efton United",
                "Federal_id":"41592024",
                "Address_1": "3000 Aston Ave",
                "Address_2":"Suite 300",
                "City":"Chicago",
                "State":"CA",
                "Zip":"98400",
                "Phone": "415 699 5637",
                "Fax": "415 777 55555",
                "Type": [
                    {
                     "TypeId": 1,
                      "TypeValue": "Accountant"
                    },
                    {
                     "TypeId": 2,
                      "TypeValue": "Architect"
                    },
                    {
                     "TypeId": 3,
                      "TypeValue": "Attorney"
                    },
                    {
                     "TypeId": 4,
                      "TypeValue": "Developer"
                    },
                    {
                     "TypeId": 5,
                      "TypeValue": "Escrow Agent"
                    },
                    {
                     "TypeId": 6,
                      "TypeValue": "FM HA District"
                    },
                    {
                     "TypeId": 7,
                      "TypeValue": "FM HA State"
                    },
                    {
                     "TypeId": 8,
                      "TypeValue": "General Contractor"
                    },
                    {
                     "TypeId": 9,
                      "TypeValue": "General Partner"
                    },
                    {
                     "TypeId": 10,
                      "TypeValue": "Investor"
                    },
                    {
                     "TypeId": 11,
                      "TypeValue": "Guarantor"
                    },
                    {
                     "TypeId": 12,
                      "TypeValue": "Lender"
                    },
                    {
                     "TypeId": 13,
                      "TypeValue": "Management Company"
                    },
                    {
                     "TypeId": 14,
                      "TypeValue": "Special LP"
                    },
                    {
                     "TypeId": 15,
                      "TypeValue": "Tax Accountant"
                    },

                    {
                     "TypeId": 16,
                      "TypeValue": "3rd Party Inspector"
                    },
                    {
                     "TypeId": 17,
                      "TypeValue": "Other"
                    }
                ],
                "Contacts": [
                    {
                        "ContactId": 1,
                        "FirstName": "Leandro",
                        "LastName": "Smith",
                        "Phone": "214 2323 3123",
                        "Position": "Analyst",
                        "Department": "Finance"
                    },
                    {
                        "ContactId": 2,
                        "FirstName": "Leandro",
                        "LastName": "Kyle",
                        "Phone": "214 2100 3123",
                        "Position": "Specialyst",
                        "Department": "Accounting"
                    },
                    {
                        "ContactId": 3,
                        "FirstName": "Leandro",
                        "LastName": "Luis",
                        "Phone": "214 2323 5100",
                        "Position": "Manager",
                        "Department": "Marketing"
                    }
                ]
            }        
        ];

        /// using get request
        // return this.http.get(this.companiesUrl)
        //     // ...and calling .json() on the response to return data
        //     .map((res: Response) => res.json())
        //     //.map((comp: Response) => <CompanyData[]>comp)
        //     //...errors if any
        //     .catch((error: any) => Observable.throw(error.json().error || 'Server error'));

        // this.http.get(this.companiesUrl)
        //     .subscribe(res => this.data = res.json());

        // console.log(this.data);
        // this.http.get(this.companiesUrl)
        //     .map((comp: Response) => comp.json());
        //     //.subscribe(res => this.companies = res.json());
        // console.log(this.companies);
        // return this.companies;
    }
}