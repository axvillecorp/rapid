
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import {ContactData} from './contactData';

/// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class ContactService {

    /// Resolve HTTP using the constructor
    // constructor(private http: Http) { }

    /// private instance variable to hold base url
    private contactsUrl = 'app/appData.json';

    /// Get companoes from server...
    getContacts(): any {

        /// return data
        return [
            {
                "Id": 1000,
                "Name": "Cristiano Ronaldo",
                
                "Position":"Accountant",
                
                "Department":"Finance",
                
                "Work_Ext":"415 777 1717, 7777",
                
                "Phone": "415 777 7777",
                "Fax": "415 007 0007",
                "Email": "cristiano.ronaldo@madrid.com",
                "Company_Relationship":"Madrid-Lender",
                
                "Companies": [
                    {
                        "FirstName": "TSTFN101",
                        "LastName": "TSTLN101",
                        "Phone": "415 777 7777",
                        "Name": "dsf",
                        "Sex": "M"
                    },
                    {
                        "FirstName": "TSTFN102",
                        "LastName": "TSTLN102",
                        "Phone": "12123 2323 3123",
                        "Sex": "M"
                    },
                    {
                        "FirstName": "TSTFN103",
                        "LastName": "TSTLN103",
                        "Phone": "12123 2323 3123",
                        "Sex": "M"
                    }
                ]
            },
            {
                "Id": 1001,
                "Name": "Gareth Bale",
                 "Position":"Analyst",
                
                "Department":"Finance",
                
                "Work_Ext":"415 232 1717, 7997",
                
                "Phone": "415 699 1111",
                "Fax": "415 787 9899",
                "Email": "gareth.bale@real.com",
                
                "Company_Relationship":"Real-Lender",
                "Contacts": [
                    {
                        "FirstName": "TSTFN101",
                        "LastName": "TSTLN101",
                        "Phone": "12123 2323 3123",
                        "Sex": "M"
                    }
                ]
            },
            {
                "Id": 1002,
                "Name": "Marco Reus",
                 "Position":"Accountant",
                
                "Department":"Finance",
                
                "Work_Ext":"415 434 1717, 4377",
                
                "Phone": "415 111 1111",
                "Fax": "415 787 8787",
                "Email": "marco.reus@dortmund.com",
                
                "Company_Relationship":"Dortmund-Lender",
                "Contacts": [
                    {
                        "FirstName": "TSTFN101",
                        "LastName": "TSTLN101",
                        "Phone": "12123 2323 3123",
                        "Sex": "M"
                    },
                    {
                        "FirstName": "TSTFN103",
                        "LastName": "TSTLN103",
                        "Phone": "12123 2323 3123",
                        "Sex": "M"
                    }
                ]
            },
            {
                "Id": 1003,
                "Name": "Neymar Jr",
                 "Position":"Accountant",
                
                "Department":"Finance",
                
                "Work_Ext":"415 432 1717, 2277",
                
                "Phone": "414 787 6768",
                "Fax": "415 767 8896",
                "Email": "neymar.jr@brazil.com",
                "Company_Relationship":"Brazil-Architect",
                
                "Contacts": [
                    {
                        "FirstName": "TSTFN102",
                        "LastName": "TSTLN102",
                        "Phone": "12123 2323 3123",
                        "Sex": "M"
                    },
                    {
                        "FirstName": "TSTFN103",
                        "LastName": "TSTLN103",
                        "Phone": "12123 2323 3123",
                        "Sex": "M"
                    }
                ]
            }
        ];

        /// using get request
        // return this.http.get(this.companiesUrl)
        //     // ...and calling .json() on the response to return data
        //     .map((res: Response) => res.json())
        //     //.map((comp: Response) => <CompanyData[]>comp)
        //     //...errors if any
        //     .catch((error: any) => Observable.throw(error.json().error || 'Server error'));

        // this.http.get(this.companiesUrl)
        //     .subscribe(res => this.data = res.json());

        // console.log(this.data);
        // this.http.get(this.companiesUrl)
        //     .map((comp: Response) => comp.json());
        //     //.subscribe(res => this.companies = res.json());
        // console.log(this.companies);
        // return this.companies;
    }
}