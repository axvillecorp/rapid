import {Component} from '@angular/core';
import {Http, Headers} from '@angular/http';
import {Router} from '@angular/router';
import {ContactService} from '../company/contact.service'
import {Observable} from 'rxjs/Observable'
import {ContactData} from '../company/contactData'

@Component({
    selector: "contacts",
    templateUrl: "./contacts.html",
    providers: [ContactService]
})
export class ContactComponent {
    contacts: any;
    contactName: string;

    /// constructor to set...
    constructor(private contactService: ContactService,
        private router: Router) {

        /// map it with contact Data
        this.contacts = contactService.getContacts().map(comp => <ContactData[]>comp);
    }

    /// track contact name search
    getContacts() {

        /// map it with contact Data
        this.contacts = this.contactService.getContacts().map(comp => <ContactData[]>comp);
    }

    /// Add new contact...
    AddNew() {

        /// navigate to add contact
        this.router.navigateByUrl("/contact");
    }
    
    /// Edit contact...
    Edit(id) {

        /// navigate to edit contact
        this.router.navigateByUrl("/contact/edit/" + id);
    }
}