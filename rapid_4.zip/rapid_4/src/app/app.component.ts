import {Component} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app',
  templateUrl: './app.component.html',
   styleUrls: [ 
        "./styles/appmain.css", 
        "./styles/app.floating-label.css", 
        "./styles/sticky-footer.css", ]
})
export class AppComponent {

  /// Initializers
    menu: string = "companies";
    pageHeader: string = "MAINTENANCE COMPANIES";
    currentYear: number = new Date().getFullYear();

    /// constructor to set...
    constructor(
        private router: Router) {
    }

    /// Go to module...
    ToModule(menuItem) {

        /// set the menu item...
        this.menu = menuItem;
        this.router.navigateByUrl("/" + menuItem);

        /// set page header...
        this.setPageHeader();
    };

    /// set page header...
    setPageHeader() {

        /// set the menu item...
        this.pageHeader = "MAINTENANCE " + this.menu.toUpperCase();
    };
}
