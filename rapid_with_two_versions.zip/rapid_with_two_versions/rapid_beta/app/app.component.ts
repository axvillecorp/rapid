/// Base compoonents
import { Component } from 'angular2/core';
import { RouteConfig } from 'angular2/router';
import { Http, HTTP_PROVIDERS, Headers } from 'angular2/http';
import { Router } from 'angular2/router';

/// Custom compoonents
import { CompanyComponent } from './maintenance/company/company.component';
import { AddEditCompanyComponent } from './maintenance/company/addeditcompany.component';
import { ContactComponent } from './maintenance/company/contact.component';
import { AddEditContactComponent } from './maintenance/company/addeditcontact.component';

/// Import router directives
import { ROUTER_DIRECTIVES } from 'angular2/router';

/// Component data
@Component({
    selector: 'my-app',
    templateUrl: '/app/app.html',
    directives: [CompanyComponent, ContactComponent, AddEditCompanyComponent, ROUTER_DIRECTIVES]
})
/// routes
@RouteConfig([
    { path: "/", name: "/companies", component: CompanyComponent, useAsDefault: true },
    { path: "/companies", name: "/companies", component: CompanyComponent },
    { path: "/company", name: "/company", component: AddEditCompanyComponent },
    { path: "/company/edit/:id", name: "/company/edit/:id", component: AddEditCompanyComponent },
    { path: "/contacts", name: "/contacts", component: ContactComponent },
    { path: "/contact", name: "/contact", component: AddEditContactComponent },
    { path: "/contact/edit/:id", name: "/contact/edit/:id", component: AddEditContactComponent },
    
])
/// App component
export class AppComponent {

    /// Initializers
    menu: string = "companies";
    pageHeader: string = "MAINTENANCE COMPANIES";
    currentYear: number = new Date().getFullYear();

    /// constructor to set...
    constructor(
        private router: Router) {
    }

    /// Go to module...
    ToModule(menuItem) {

        /// set the menu item...
        this.menu = menuItem;
        this.router.navigateByUrl("/" + menuItem);

        /// set page header...
        this.setPageHeader();
    };

    /// set page header...
    setPageHeader() {

        /// set the menu item...
        this.pageHeader = "MAINTENANCE " + this.menu.toUpperCase();
    };
}