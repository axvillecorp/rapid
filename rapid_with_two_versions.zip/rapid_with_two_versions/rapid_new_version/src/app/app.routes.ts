import { Routes } from '@angular/router';

/// Custom compoonents
import { CompanyComponent } from './maintenance/company/company.component';
import { AddEditCompanyComponent } from './maintenance/company/addeditcompany.component';
import { ContactComponent } from './maintenance/company/contact.component';
import { AddEditContactComponent } from './maintenance/company/addeditcontact.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { RepoBrowserComponent } from './github/repo-browser/repo-browser.component';
import { RepoListComponent } from './github/repo-list/repo-list.component';
import { RepoDetailComponent } from './github/repo-detail/repo-detail.component';

export const rootRouterConfig: Routes = [
  {
    path: '',
    pathMatch: 'prefix', //default
    redirectTo: 'companies'
  },
  { path: "companies", component: CompanyComponent },
  { path: "company", component: AddEditCompanyComponent },
  { path: "company/edit/:id", component: AddEditCompanyComponent },
  { path: "contacts", component: ContactComponent },
  { path: "contact", component: AddEditContactComponent },
  { path: "contact/edit/:id", component: AddEditContactComponent },
];

